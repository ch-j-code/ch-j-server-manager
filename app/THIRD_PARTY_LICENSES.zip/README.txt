CH-J Server Manager — Complete Third-Party License Package

This archive contains the license texts and notices for third-party software
distributed by CH-J Server Manager Core.
The project itself is licensed separately under Apache License 2.0.

Contents:
- THIRD_PARTY_NOTICES.txt: Production Node.js dependency licenses
- ELECTRON_LICENSE.txt: Electron license
- CHROMIUM_LICENSES.html: Chromium and embedded component licenses
