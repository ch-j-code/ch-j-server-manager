CH-J Server Manager — Complete Third-Party License Package

This archive contains the license texts and notices for third-party software
distributed by CH-J Server Manager Core and its bundled source components.
The project itself is licensed separately under Apache License 2.0.

Contents:
- THIRD_PARTY_NOTICES.txt: Production Node.js dependency licenses
- ELECTRON_LICENSE.txt: Electron license
- CHROMIUM_LICENSES.html: Chromium and embedded component licenses
- MONACO_LICENSE.txt: Monaco Editor license
- MONACO_THIRD_PARTY_NOTICES.txt: Monaco Editor third-party notices
- GOOGLE_CITYHASH_LICENSE.txt: Ported CityHash implementation license
- FB_TIGER_HASH_LICENSE.txt: Bundled Tiger/Tiger2 implementation license
